/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;
import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author WillOP
 */
public class Actualizacion {
    
    public boolean Modificar_estado_cuenta(int id_cliente_banco, String tipocuenta , String estadocuenta){        
        
        Connection conexion=null;
        
        String query="UPDATE Cuenta set Estado_cuenta='"+estadocuenta+"' where ID_cliente_banco="+id_cliente_banco+" and Tipo_cuenta='"+tipocuenta+"'; ";
              
        try {
            //variable coneccion = nueva (nombre del paquete)con el metodo a obtener
            conexion = new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement(); 
            ResultSet rs = stmt.executeQuery(query);           
            conexion.close();
            
            return true;
        } catch (Exception e) {
          System.err.println("eror al ejecutar el query modificar estado de cuenta "+e.getMessage() );
            return false;
        }
    }
    

    public boolean Cambiar_contraseña(int cui_dpi,String pasword, String tipo_cliente, String nuevo_pasword){        
        
        Connection conexion=null;
        int cui;
        String ppasword;
        
        String query1="Select * from cliente_banco where CUI="+cui_dpi;
        String query="UPDATE Cliente_banco set Contraseña="+nuevo_pasword+" where CUI="+cui_dpi+" and Tipo_cliente='"+tipo_cliente+"'; ";
          
        try{
        conexion = new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement(); 
            ResultSet rs = stmt.executeQuery(query1); 
            while(rs.next()){
                cui=rs.getInt("CUI");
                ppasword=rs.getString("Contraseña");
                if (cui == cui_dpi) {
                    if (ppasword.equals(pasword)) {
                        Statement stmt2 = conexion.createStatement(); 
                        ResultSet rs2 = stmt2.executeQuery(query);                
                        rs2.close();
                        System.out.println("si entro al while");
                        return true;
                    }
                    else{
                        System.out.println("no entro al segundo if");
                    }
                }
                else{
                    System.out.println("no entro al primer if");
                }
            }
            
            rs.close();
            conexion.close();

        }
        catch(Exception ee){
        System.err.println("error en consulta para cambiar contraseña "+ee.getMessage() );
return false;
        }
        return false;
    }
    
    public boolean modificar_contraseña(int cui_dpi,String pasword, String tipo_cliente, String nuevo_pasword){        
        
        Connection conexion=null;
        int cui;
        String ppasword;
        
        String query1="Select * from cliente_banco where CUI="+cui_dpi;
        String query="UPDATE Cliente_banco set Contraseña="+nuevo_pasword+" where CUI="+cui_dpi+" and Tipo_cliente='"+tipo_cliente+"'; ";
          
        try{
        conexion = new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement(); 
            ResultSet rs = stmt.executeQuery(query1); 
            while(rs.next()){
                cui=rs.getInt("CUI");
                ppasword=rs.getString("Contraseña");
                if (cui == cui_dpi) {
                    if (ppasword.equals(pasword)) {
                        Statement stmt2 = conexion.createStatement(); 
                        ResultSet rs2 = stmt2.executeQuery(query);                
                        rs2.close();
                        System.out.println("si entro al while");
                    }
                    else{
                        System.out.println("no entro al segundo if");
                    }
                }
                else{
                    System.out.println("no entro al primer if");
                }
            }
            
            rs.close();
            conexion.close();
            return true;
        }
        catch(Exception ee){
        System.err.println("error en consulta para cambiar contraseña "+ee.getMessage() );
return false;
        }
    }
    
            public Boolean añadirgerenteagencia (int id_agencia, String nombregerente){
            
            Connection conexion=null;
            String query="Insert into Gerente_agencia(ID_agencia, Nombre_gerente) values("+id_agencia+", '"+nombregerente+"' );";
            
            try {
            conexion= new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement();
            ResultSet resultado = stmt.executeQuery(query);
            resultado.close();
            conexion.close();
            return true;
        } catch (Exception e) {
            System.err.println("eror al ejecutar el query de añadir gerente a agencia   "+e.getMessage() );
            return false;
        }   
            
}
            
    public Boolean depositoefectivo(int num_cuenta, int cui, Double monto){
               Connection conexion=null;
        Double dinero_cuenta;
        Double resultado;
        String query2="Select Cantidad_dinero from cuenta where ID_cuenta="+num_cuenta;
       
        try {
            //variable coneccion = nueva (nombre del paquete)con el metodo a obtener
            conexion = new Conexion().ObtenerConeccion();
            //segunda consulta
            Statement stmt2 = conexion.createStatement(); 
            ResultSet rs2 = stmt2.executeQuery(query2);  
            dinero_cuenta=rs2.getDouble("Cantidad_dinero");
            rs2.close();
            resultado=monto+dinero_cuenta;
            String query3="UPDATE cuenta set cantidad_dinero="+resultado+" where ID_cuenta="+num_cuenta;       
            //tercera consulta
            Statement stmt3 = conexion.createStatement(); 
            ResultSet rs3 = stmt3.executeQuery(query3);     
            conexion.close();
            return true;
        } catch (Exception e) {
          System.err.println("eror al ejecutar el query de depositoefectivo   "+e.getMessage() );
            return false;
        }
    }
}

