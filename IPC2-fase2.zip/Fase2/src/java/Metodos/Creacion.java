/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Metodos;


import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/**
 *
 * @author WillOP
 */
public class Creacion {

    
    public boolean crearusuario(int idr,int dpir, int telefonor, int direccionr){
        int id,dpi,telefono,direccion;
        id=idr;
        dpi=dpir;
        telefono=telefonor;
        direccion= direccionr;
        Connection conexion=null;
        
        String query="Insert into ejemplo(id_estudiante , dpi , telefono , direccion ) values(" + id +" , "+ dpi +" , "+telefono+" , "+direccion+");";
        
        
        try {
            //variable coneccion = nueva (nombre del paquete)con el metodo a obtener
            conexion = new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement(); 
            ResultSet rs = stmt.executeQuery(query);           
            conexion.close();
            return true;
        } catch (Exception e) {
          System.err.println("dfadjfalksdjf   eror al ejecutar el query    "+e.getMessage() );
            return false;
        }

        
    }
    
    
    
    public boolean crearinstitucion_empresarial(String nombre_institucionr, String usuarior, String paswordr, String Presidenter, String Viceprer, String Contadorr, String patenter){
        String nombre=nombre_institucionr;
        String usuario = usuarior;
        String pasword = paswordr;
        String presidente = Presidenter;
        String viceprecidente = Viceprer;
        String contador = Contadorr;
        String patente = patenter;
        
        Connection conexion=null;
        
        String query="Insert into Institucion_empresarial(Nombre_institucion, usuario_empresa, contraseña_empresa, presidente_empresa, viceprecidente_empresa, contador_empresa, patente_empresa ) values('" + nombre +"' , '"+ usuario +"' , '"+ pasword +"' , '"+ presidente +"' , '"+ viceprecidente +"' , '"+ contador +"' , '"+ patente +"');";
        
        
        try {
            //variable coneccion = nueva (nombre del paquete)con el metodo a obtener
            conexion = new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement(); 
            ResultSet rs = stmt.executeQuery(query);           
            conexion.close();
            return true;
        } catch (Exception e) {
          System.err.println("eror al ejecutar el query de nueva empresa   "+e.getMessage() );
            return false;
        }

        
    }
    
    public boolean Crear_cuenta(int id_cliente,String estado_cuenta, int intereses, String Tipo_cuenta, Double Cantidad_dinero){        
        
        Connection conexion=null;
        
        String query="Insert into Cuenta(ID_cliente_banco, Estado_cuenta , Intereses, Tipo_cuenta, Cantidad_dinero ) values("+id_cliente+" ,'" + estado_cuenta +"' , "+ intereses +" , '"+ Tipo_cuenta+"' , "+ Cantidad_dinero+");";
              
        try {
            //variable coneccion = nueva (nombre del paquete)con el metodo a obtener
            conexion = new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement(); 
            ResultSet rs = stmt.executeQuery(query);           
            conexion.close();
            return true;
        } catch (Exception e) {
          System.err.println("eror al ejecutar el query de nueva cuenta   "+e.getMessage() );
            return false;
        }

        
    }
    
        public boolean Solicitar_prestamo(int ID_operario_tabla,int ID_cuenta_tabla,String estado_aprobacion, double monto, String modalidad_pagar ){        
        
        Connection conexion=null;
        
        String query="Insert into solicitud_prestamo(ID_operario_tabla, ID_cuenta_tabla, Estado_aprobacion, Monto, Modalidad_pagar ) values("+ID_operario_tabla+" , " +ID_cuenta_tabla +" , '"+ estado_aprobacion +"' , "+ monto+" , '"+ modalidad_pagar+"');";
              
        try {
            //variable coneccion = nueva (nombre del paquete)con el metodo a obtener
            conexion = new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement(); 
            ResultSet rs = stmt.executeQuery(query);           
            conexion.close();
            return true;
        } catch (Exception e) {
          System.err.println("eror al ejecutar el query de solicitud de prestamo   "+e.getMessage() );
            return false;
        }

        
    }


        public boolean Crear_nomina(int id_institucionr,String nomina){        
        
        Connection conexion=null;
        
        String query="Insert into Nomina_empleados(ID_institucion, Nombre_nomina) values("+id_institucionr+" , '" +nomina +"' );";
             
        try {
            //variable coneccion = nueva (nombre del paquete)con el metodo a obtener
            conexion = new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement(); 
            ResultSet rs = stmt.executeQuery(query);           
            conexion.close();
            return true;
        } catch (Exception e) {
          System.err.println("eror al ejecutar el query de creacion de nomina   "+e.getMessage() );
            return false;
        }

        
    }
                public boolean Crear_empleado(int cui, String nombre, String fecha, String sexo, String usuario, String password){        
        
        Connection conexion=null;
        
        String query="Insert into cliente_banco(CUI, Nombre_completo, Fecha_nacimiento, sexo, Tipo_cliente, Usuario, Contraseña) values('"+cui+"' , '"+nombre+"' , '"+fecha+"' , '"+sexo+"' , 'Empleado' , '"+usuario+"' , '"+password+"' );";
             
        try {
            //variable coneccion = nueva (nombre del paquete)con el metodo a obtener
            conexion = new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement(); 
            ResultSet rs = stmt.executeQuery(query);           
            conexion.close();
            return true;
        } catch (Exception e) {
          System.err.println("eror al ejecutar el query de creacion de empleado   "+e.getMessage() );
            return false;
        }

        
    }
                
         
        
        
public Boolean cambiarcheque(int numero_cuenta,int id_operario,int correlativo, Double monto,String destinatario){
        Connection conexion=null;
        Double dinero_cuenta;
        Double resultado;
        
        String query="Insert into cheque(ID_cuenta, ID_operario, Correlativo_cheque, Monto, Destinatario_cheque) values("+numero_cuenta+","+id_operario+" ,"+correlativo+" ,"+monto+" , '"+destinatario+"');";
        String query2="Select Cantidad_dinero from cuenta where ID_cuenta="+numero_cuenta;
       
        try {
            //variable coneccion = nueva (nombre del paquete)con el metodo a obtener
            conexion = new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement(); 
            ResultSet rs = stmt.executeQuery(query);
            rs.close();
            //segunda consulta
//            Statement stmt2 = conexion.createStatement(); 
//            ResultSet rs2 = stmt2.executeQuery(query);  
//            
//            dinero_cuenta=rs2.getDouble("Cantidad_dinero");
//            
//            rs2.close();
//            resultado=monto-dinero_cuenta;
//            String query3="UPDATE cuenta set cantidad_dinero="+resultado+" where ID_cuenta="+numero_cuenta;       
//            //tercera consulta
//            Statement stmt3 = conexion.createStatement(); 
//            ResultSet rs3 = stmt3.executeQuery(query3);     
            conexion.close();
            return true;
        } catch (Exception e) {
          System.err.println("eror al ejecutar el query de cambiar cheque   "+e.getMessage() );
            return false;
        }
}         

public Boolean Depositocheque(int numero_cuenta,int id_operario,int correlativo, Double monto,String destinatario){
                Connection conexion=null;
        Double dinero_cuenta;
        Double resultado;
        
        String query="Insert into cheque(ID_cuenta, ID_operario, Correlativo_cheque, Monto, Destinatario_cheque) values("+numero_cuenta+","+id_operario+" ,"+correlativo+" ,"+monto+" , '"+destinatario+"');";
        String query2="Select Cantidad_dinero from cuenta where ID_cuenta="+numero_cuenta;
       
        try {
            //variable coneccion = nueva (nombre del paquete)con el metodo a obtener
            conexion = new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement(); 
            ResultSet rs = stmt.executeQuery(query);
            rs.close();
            //segunda consulta
//            Statement stmt2 = conexion.createStatement(); 
//            ResultSet rs2 = stmt2.executeQuery(query2);  
//            dinero_cuenta=rs2.getDouble("Cantidad_dinero");
//            rs2.close();
//            resultado=monto+dinero_cuenta;
//            String query3="UPDATE cuenta set cantidad_dinero="+resultado+" where ID_cuenta="+numero_cuenta;       
//            //tercera consulta
//            Statement stmt3 = conexion.createStatement(); 
//            ResultSet rs3 = stmt3.executeQuery(query3);     
            conexion.close();
            return true;
        } catch (Exception e) {
          System.err.println("eror al ejecutar el query de deposito cheque   "+e.getMessage() );
            return false;
        }
}

    public Boolean Crearnuevaagencia (String nombre_agencia, String direccion, String telefono){
            Connection conexion=null;
            String query="Insert into Agencia(Nombre_agencia,Direccion_agencia, Telefono_agencia) values('"+nombre_agencia+"', '"+direccion+"', '"+telefono+"' );";
            
            try {
            conexion= new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement();
            ResultSet resultado = stmt.executeQuery(query);
            conexion.close();
            return true;
        } catch (Exception e) {
            System.err.println("eror al ejecutar el query de crear agencia   "+e.getMessage() );
            return false;
        }
    }
            

        
    public Boolean añadirempleadoagencia (String nombre, String apellido, String telefono, String tipo, int id_agencia, int id_gerente){
            Connection conexion=null;
            String query="Insert into Operario(Nombre_operario, Apellido_operario, Telefono, Tipo_operario, ID_agencia, ID_gerente_agencia) values( '"+nombre+"', '"+apellido+"', '"+telefono+"', '"+tipo+"', "+id_agencia+" , "+id_gerente +");";
            
            try {
            conexion= new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement();
            ResultSet resultado = stmt.executeQuery(query);
            resultado.close();
            conexion.close();
            return true;
        } catch (Exception e) {
            System.err.println("eror al ejecutar el query de añadirempleado a una agencia   "+e.getMessage() );
            return false;
        }   
            
}
    
    
    public Boolean depositoefectivo(int num_cuenta, int cui, Double monto){
               Connection conexion=null;
        Double dinero_cuenta;
        Double resultado;
        String query2="Select Cantidad_dinero from cuenta where ID_cuenta="+num_cuenta;
       
        try {
            //variable coneccion = nueva (nombre del paquete)con el metodo a obtener
            conexion = new Conexion().ObtenerConeccion();
            //segunda consulta
            Statement stmt2 = conexion.createStatement(); 
            ResultSet rs2 = stmt2.executeQuery(query2);  
            dinero_cuenta=rs2.getDouble("Cantidad_dinero");
            rs2.close();
            resultado=monto+dinero_cuenta;
            String query3="UPDATE cuenta set cantidad_dinero="+resultado+" where ID_cuenta="+num_cuenta;       
            //tercera consulta
            Statement stmt3 = conexion.createStatement(); 
            ResultSet rs3 = stmt3.executeQuery(query3);     
            conexion.close();
            return true;
        } catch (Exception e) {
          System.err.println("eror al ejecutar el query de depositoefectivo   "+e.getMessage() );
            return false;
        }
    }

    
    
}

