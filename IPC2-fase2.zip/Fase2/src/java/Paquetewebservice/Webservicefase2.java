/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Paquetewebservice;

import Consultas.Consultacuentanomina;
import Metodos.Actualizacion;
import Metodos.Creacion;
import Consultas.Login;
import Metodos.Actualizacion;
import Conexion.Conexion;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author WillOP
 */
@WebService(serviceName = "Webservicefase2")
public class Webservicefase2 {

    /**
     * This is a sample web service operation
     */
@WebMethod(operationName = "Nuevoinformacion")
public Boolean Registrar(@WebParam(name="id") int id,@WebParam(name="dpi") int dpi,@WebParam(name="telefono") int telefono,@WebParam(name="direccion") int direccion)
{
return (new Creacion().crearusuario(id,dpi,telefono,direccion));
}
 /**

  * 
  */
@WebMethod(operationName = "Login")
public Boolean Login(@WebParam(name="usuario") String usuario,@WebParam(name="password") String password)
{
return (new Login().login(usuario, password));
}


@WebMethod(operationName = "Aperturacuentaindividual")
public Boolean Aperturacuentaindividual(@WebParam(name="cui") int idcui,@WebParam(name="estadocuenta") String estado,@WebParam(name="intereses") int intereses, @WebParam(name="tipocuenta") String tipo, @WebParam(name="dinero") Double dinero)
{
return (new Creacion().Crear_cuenta(idcui,estado,intereses,tipo,dinero));
}

@WebMethod(operationName = "Solicituddeprestamo")
public Boolean Solicitudprestamo(@WebParam(name="idoperario") int idoperario,@WebParam(name="idcuenta") int idcuenta,@WebParam(name="estado_solicitud") String estadosoli,@WebParam(name="monto") Double monto, @WebParam(name="modo_depago") String modo)
{
return (new Creacion().Solicitar_prestamo(idoperario,idcuenta,estadosoli,monto,modo));
}

@WebMethod(operationName = "Aperturacuentaempresarial")
public Boolean Creacioncuentaempresarial(@WebParam(name="nombreinstitucion") String nombre,@WebParam(name="usuario") String usuario,@WebParam(name="password") String password, @WebParam(name="presidente") String precidente, @WebParam(name="viceprecidente") String vice,@WebParam(name="contador") String contador,@WebParam(name="patente") String patente)
{
return (new Creacion().crearinstitucion_empresarial(nombre,usuario,password,precidente,vice,contador,patente));
}

///

@WebMethod(operationName = "Estadocuenta")
public Boolean Estadocuenta(@WebParam(name="idcui") int idcliente,@WebParam(name="tipocuenta") String tipo,@WebParam(name="Nuevoestado") String estado)
{
return (new Actualizacion().Modificar_estado_cuenta(idcliente,tipo,estado));
}
///
@WebMethod(operationName = "Modificarcontraseña")
public Boolean Modificarcontraseña(@WebParam(name="idcui") int idcliente,@WebParam(name="password") String password,@WebParam(name="tipo") String tipo,@WebParam(name="Nuevopassword") String npassword)
{
return (new Actualizacion().Cambiar_contraseña(idcliente, password, tipo, npassword));
}

@WebMethod(operationName = "crearnomina")
public Boolean Aperturanomina(@WebParam(name="idinstitucion") int idinst ,@WebParam(name="Nombrenomina") String nombre)
{
return (new Creacion().Crear_nomina(idinst, nombre));
}

@WebMethod(operationName = "consultarnomina")
public String Consultarnomina(@WebParam(name="cui") int idinst ,@WebParam(name="Nombrenomina") String nombre)
{
return (new Consultacuentanomina().Consultarusuarionomina(nombre, idinst));
}

@WebMethod(operationName = "crearempleadonomina")
public Boolean Crearempleado(@WebParam(name="idcui") int cui,@WebParam(name="nombre") String nombre,@WebParam(name="fecha") String fecha, @WebParam(name="sexo") String sexo, @WebParam(name="usuario") String usuario,@WebParam(name="password") String password)
{
return (new Creacion().Crear_empleado(cui,nombre,fecha,sexo,usuario,password));
}

@WebMethod(operationName = "Asignarempleadonomina")
public Boolean asignarempleadonomina(@WebParam(name="idcui") int cui,@WebParam(name="nombrenomina") String nombrenomina)
{
return (new Consultacuentanomina().Asignarempleadonomina(cui, nombrenomina));
}

@WebMethod(operationName = "cambiarcheque")
public Boolean cambiarcheque(@WebParam(name="numerocuenta") int numcuenta,@WebParam(name="idoperario") int operario, @WebParam(name="correlativo") int correlativo, @WebParam(name="monto") Double monto ,@WebParam(name="destinatario") String destinatario)
{
return (new Creacion().cambiarcheque(numcuenta, operario, correlativo, monto, destinatario));
}
@WebMethod(operationName = "Depositosefectivo")
public Boolean Depositoefectivo(@WebParam(name="numerocuenta") int numcuenta,@WebParam(name="idcliente") int id_cliente, @WebParam(name="monto") Double monto )
{
return (new Actualizacion().depositoefectivo(numcuenta, id_cliente, monto));
}
@WebMethod(operationName = "Depositoscheque")
public Boolean Depositocheque(@WebParam(name="numerocuenta") int numcuenta,@WebParam(name="idcliente") int id_cliente,@WebParam(name="correlativo") int corre, @WebParam(name="monto") Double monto,@WebParam(name="destinatario") String destinatario )
{
return (new Creacion().Depositocheque(numcuenta, id_cliente, corre, monto, destinatario));
}

////
@WebMethod(operationName = "Crearagencia")
public Boolean Crearagencia(@WebParam(name="nombreagencia") String nombre,@WebParam(name="direccion_agencia") String direccion, @WebParam(name="telefono") String telefono )
{
return (new Creacion().Crearnuevaagencia(nombre, direccion, telefono));
}

////



@WebMethod(operationName = "añadirgerente")
public Boolean añadirgerente(@WebParam(name="idagencia") int idagencia,@WebParam(name="nombre_agencia") String nombre )
{
return ( new Actualizacion().añadirgerenteagencia(idagencia, nombre));
}
    
   @WebMethod(operationName = "Añadirempleado")
public Boolean añadirempleado(@WebParam(name="nombreagencia") String nombre,@WebParam(name="apellido") String apellido, @WebParam(name="telefono") String telefono ,@WebParam(name="tipo") String tipo, @WebParam(name="idagencia") int idagencia, @WebParam(name="idgerente") int id_gerente )
{
return (new Creacion().añadirempleadoagencia(nombre, apellido, telefono, tipo, idagencia, id_gerente));
} 

}
