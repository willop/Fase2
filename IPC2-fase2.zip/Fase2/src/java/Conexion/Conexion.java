/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author WillOP
 */
public class Conexion {
            private String drivedb="org.mariadb.jdbc.Driver";
            private String nombrebasededatos="fase2";
            private String nombre="root";
            private String contraseña="Wilfredpaco123";
            
    public Connection ObtenerConeccion(){
        Connection DBconnection=null;//registro coneccion como nula
        
        try{
            Class.forName(drivedb);
        }catch(ClassNotFoundException e){
            System.out.println("mensaje de error en conexion"+e.getMessage());
        }
        try{
            DBconnection= DriverManager.getConnection("jdbc:mariadb://localhost/"+nombrebasededatos,nombre,contraseña);
            return DBconnection;
        }catch(SQLException e){
            System.out.println("error de sql"+e.getMessage());
        }
        return DBconnection;

}
}
