/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Consultas;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**
 *
 * @author WillOP
 */
public class Login {
    
    Connection con=null;
    public Boolean login(String usuarior, String paswordr){
            String usuario;
            String pasword;
        String query="Select Cliente_banco.Usuario, Cliente_banco.Contraseña from cliente_banco where cliente_banco.usuario='"+usuarior+"'";
        
        try{
        con = new Conexion().ObtenerConeccion();
            Statement stmt = con.createStatement(); 
            ResultSet rs = stmt.executeQuery(query); 
            while(rs.next()){
                usuario=rs.getString("usuario");
                pasword=rs.getString("contraseña");
                if (usuario.equals(usuarior)) {
                    if (pasword.equals(paswordr)) {
                        return true;
                    }
                    else{
                    return false;
                    }
                }
                else{
                return false;
                }
            }
            con.close();

        }
        catch(Exception ee){
        System.err.println("error en consulta para log in "+ee.getMessage() );
return false;
        }
return false;
       }
}
