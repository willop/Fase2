/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Consultas;
import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
/**
 *
 * @author WillOP
 */
public class Consultacuentanomina {
        int id_nomina;
        int id_cui;

    public String Consultarusuarionomina(String nombrenomina, int cuiempleado){
        Vector a=new Vector<>();
        String nombre11 = null,fecha11=null,sexo11=null,tipocliente11=null;
        Connection con=null;
        String query="Select ID_nomina from nomina_empleados where nomina_empleados.Nombre_nomina='"+nombrenomina+"';";
        String query2="Select CUI from detalle_nomina_empleado where ID_nomina="+id_nomina;
        String query3="Select * from cliente_banco where CUI="+id_cui;

        try{
            con = new Conexion().ObtenerConeccion();
            //primera consulta
            Statement stmt = con.createStatement(); 
            ResultSet rs = stmt.executeQuery(query); 
            while(rs.next()){
                id_nomina=rs.getInt("ID_nomina");               
            }            
            rs.close();
            //segunda consulta
            Statement stmt2 = con.createStatement(); 
            ResultSet rs2 = stmt.executeQuery(query2); 
            while(rs2.next()){
                id_cui=rs2.getInt("CUI");                   
            }            
            rs2.close();
            // tercera consulta

            Statement stmt3 = con.createStatement(); 
            ResultSet rs3 = stmt.executeQuery(query3); 
            while(rs3.next()){
                nombre11=rs.getString("Nombre_completo");
                fecha11=rs.getString("Fecha_nacimiento");
                sexo11 = rs.getString("Sexo");
                tipocliente11=rs.getString("Tipo_cliente");   

            }        
            
            rs3.close();
            
            con.close();
return "nada";
        }
        catch(Exception ee){
        System.err.println("error en consulta para usuario y nomina "+ee.getMessage() );
return"No se encontro al empleado registrado";
        }
    }
    
       public boolean Asignarempleadonomina(int cui, String nombrenomina){        
        
        Connection conexion=null;
        String query="Select ID_nomina from nomina_empleados where nomina_empleados.Nombre_nomina="+nombrenomina;
        String query2="Insert into detalle_nomina_empleado(CUI, ID_nomina) values("+id_cui+" , "+id_nomina+");";
             
        try {
            //variable coneccion = nueva (nombre del paquete)con el metodo a obtener
            conexion = new Conexion().ObtenerConeccion();
            Statement stmt = conexion.createStatement(); 
            ResultSet rs = stmt.executeQuery(query);   
                        while(rs.next()){
                id_nomina=rs.getInt("ID_nomina");               
            }            
            rs.close();
            //segunda consulta
            Statement stmt2 = conexion.createStatement(); 
            ResultSet rs2 = stmt.executeQuery(query2); 
            rs2.close();
            conexion.close();
            return true;
        } catch (Exception e) {
          System.err.println("eror al ejecutar el query de creacion de empleado   "+e.getMessage() );
            return false;
        }

        
    }
    
    
    
}
