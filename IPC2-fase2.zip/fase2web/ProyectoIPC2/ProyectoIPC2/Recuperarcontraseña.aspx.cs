﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace ProyectoIPC2
{
    public partial class Recuperarcontraseña : System.Web.UI.Page
    {
        //variables
        SqlConnection coneccion = new SqlConnection();
        string rol;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (DropDownList1.Text == "SuperUsuario")
            {
                rol = "1";
            }
            if (DropDownList1.Text == "Administrador")
            {
                rol = "2";
            }
            if (DropDownList1.Text == "Arquitecto")
            {
                rol = "3";
            }
            if (DropDownList1.Text == "Developer")
            {
                rol = "4";
            }
            //si es tester
            else if (DropDownList1.Text == "Tester")
            {
                rol = "5";
            }

            coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
            coneccion.Open();
            SqlCommand cmd = new SqlCommand("select * from USUARIO where correo ='" + TextBox1.Text + "' and CONVERT(VARCHAR, nombre) ='" + TextBox2.Text + "'", coneccion);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read() == true)
            {
                if ((dr["id_rol"].ToString()).Equals(rol))
                {
                    this.Page.Response.Write("<script language='JavaScript'>window.alert(' Bienvenido usuario ');</script>");
                    Label4.Text = dr["contraseña"].ToString();
                    coneccion.Close();
                }
                else
                {                   
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                    TextBox1.Focus();
                }
            }
            else
            {
                this.Page.Response.Write("<script language='JavaScript'>window.alert(' Correo o nombre incorrecto,     Intente de nuevo ');</script>");
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox1.Focus();
            }
            

        }
    }
}