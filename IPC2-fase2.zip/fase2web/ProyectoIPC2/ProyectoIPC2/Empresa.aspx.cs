﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProyectoIPC2
{
    public partial class DesarrolloAdministrador : System.Web.UI.Page
    { //variables
        ServiceReference1.Webservicefase2Client ws = new ServiceReference1.Webservicefase2Client();

        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                string nombreusuario = Session["usuario"].ToString();
                Label1.Text = nombreusuario;

            }
            catch (Exception ex)
            {
                Response.Redirect("Ingresar.aspx");
            }


        }




        //----------------------crear usuario
        //protected void Button2_Click(object sender, EventArgs e)
        //{
        //    if (DropDownList1.Text == "Administrador")
        //    {
        //        rol = "2";
        //    }
        //    if (DropDownList1.Text == "Arquitecto")
        //    {
        //        rol = "3";
        //    }
        //    if (DropDownList1.Text == "Developer")
        //    {
        //        rol = "4";
        //    }
        //    //si es tester
        //    else if (DropDownList1.Text == "Tester")
        //    {
        //        rol = "5";
        //    }
        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("insert into USUARIO (id_rol,correo,contraseña,nombre,fecha_nacimiento,direccion,telefono) values(" + rol + " , '" + TextBox1.Text + "' , '" + TextBox3.Text + "' , '" + TextBox2.Text + "' , '" + TextBox4.Text + "' , '" + TextBox5.Text + "' , '" + TextBox6.Text + "') ", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    dr.Close();
        //    coneccion.Close();
        //    this.Page.Response.Write("<script language='JavaScript'>window.alert('Usuario creado Exitosamente');</script>");

        //}

        ////modificar usuario por medio del correo
        //protected void Button3_Click(object sender, EventArgs e)
        //{
        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("Update USUARIO set nombre= '" + TextBox8.Text + "', fecha_nacimiento= '" + TextBox10.Text + "' ,direccion='" + TextBox11.Text + "',telefono='" + TextBox12.Text + "'   where correo='" + TextBox7.Text + "'", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    dr.Close();
        //    coneccion.Close();
        //    this.Page.Response.Write("<script language='JavaScript'>window.alert('Usuario modificado Exitosamente');</script>");
        //}

        //protected void Button4_Click(object sender, EventArgs e)
        //{
        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("delete from USUARIO where correo='" + TextBox13.Text + "' and contraseña='" + TextBox14.Text + "' ", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader();

        //    dr.Close();
        //    coneccion.Close();

        //    Label16.Text = "se elimino el registro";
        //    this.Page.Response.Write("<script language='JavaScript'>window.alert('Usuario eliminado Exitosamente');</script>");

        //}

        //cerrar cession
        protected void Button1_Click(object sender, EventArgs e)
        {
            Session.Remove("usuario");
            Response.Redirect("Ingresar.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            ws.crearnomina(Convert.ToInt32(TextBox1.Text),TextBox2.Text);
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            ws.crearempleadonomina(Convert.ToInt32(TextBox7.Text),TextBox8.Text,TextBox9.Text,TextBox3.Text,TextBox8+"usuario", TextBox8+"contraseña");
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            ws.Asignarempleadonomina(Convert.ToInt32(TextBox7.Text), TextBox6.Text);
        }

        ////crear proyecto
        //protected void Button6_Click(object sender, EventArgs e)
        //{

        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("Insert into PROYECTO (nombre, fecha_inicio , fecha_fin, presupuesto, duracion ) values('" + TextBox17.Text + "','" + TextBox18.Text + "','" + TextBox19.Text + "','" + TextBox20.Text + "','" + TextBox21.Text + "')", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    dr.Close();
        //    coneccion.Close();
        //    this.Page.Response.Write("<script language='JavaScript'>window.alert('Usuario modificado Exitosamente');</script>");

        //}

        //protected void Button7_Click(object sender, EventArgs e)
        //{

        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("Update PROYECTO set nombre='" + TextBox22.Text + "' fecha_inicio='" + TextBox23.Text + "', fecha_fin='" + TextBox24.Text + "', presupuesto='" + TextBox25.Text + "' , duracion='" + TextBox26.Text + "' where presupuesto='" + TextBox25.Text + "' ", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    dr.Close();
        //    coneccion.Close();
        //    this.Page.Response.Write("<script language='JavaScript'>window.alert('Usuario modificado Exitosamente');</script>");

        //}

        //protected void Button8_Click(object sender, EventArgs e)
        //{
        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("delete from PROYECTO where presupuesto='" + TextBox28.Text + "' and duracion='" + TextBox29.Text + "' ", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    dr.Close();
        //    coneccion.Close();
        //    this.Page.Response.Write("<script language='JavaScript'>window.alert('Usuario modificado Exitosamente');</script>");

        //}
    }
}