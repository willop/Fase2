﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProyectoIPC2
{
    public partial class Desarrolloadministrador : System.Web.UI.Page
    {       //variables
        ServiceReference1.Webservicefase2Client ws = new ServiceReference1.Webservicefase2Client();


        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string nombreusuario = Session["usuario"].ToString();
                Label1.Text = nombreusuario;

            }
            catch (Exception ex)
            {
                Response.Redirect("Ingresar.aspx");
            }


        }




        //----------------------crear usuario
        //protected void Button2_Click(object sender, EventArgs e)
        //{
        //    if (DropDownList1.Text == "Administrador")
        //    {
        //        rol = "2";
        //    }
        //    if (DropDownList1.Text == "Arquitecto")
        //    {
        //        rol = "3";
        //    }
        //    if (DropDownList1.Text == "Developer")
        //    {
        //        rol = "4";
        //    }
        //    //si es tester
        //    else if (DropDownList1.Text == "Tester")
        //    {
        //        rol = "5";
        //    }
        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("insert into USUARIO (id_rol,correo,contraseña,nombre,fecha_nacimiento,direccion,telefono) values(" + rol + " , '" + TextBox1.Text + "' , '" + TextBox3.Text + "' , '" + TextBox2.Text + "' , '" + TextBox4.Text + "' , '" + TextBox5.Text + "' , '" + TextBox6.Text + "') ", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    dr.Close();
        //    coneccion.Close();
        //    this.Page.Response.Write("<script language='JavaScript'>window.alert('Usuario creado Exitosamente');</script>");

        //}

        ////modificar usuario por medio del correo
        //protected void Button3_Click(object sender, EventArgs e)
        //{
        //    if (DropDownList2.Text == "Administrador")
        //    {
        //        rol = "2";
        //    }
        //    if (DropDownList2.Text == "Arquitecto")
        //    {
        //        rol = "3";
        //    }
        //    if (DropDownList2.Text == "Developer")
        //    {
        //        rol = "4";
        //    }
        //    //si es tester
        //    else if (DropDownList2.Text == "Tester")
        //    {
        //        rol = "5";
        //    }
        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("Update USUARIO set nombre= '" + TextBox8.Text + "', fecha_nacimiento= '" + TextBox10.Text + "' ,direccion='" + TextBox11.Text + "',telefono='" + TextBox12.Text + "', id_rol='" + rol + "'   where correo='" + TextBox7.Text + "'", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    dr.Close();
        //    coneccion.Close();
        //    this.Page.Response.Write("<script language='JavaScript'>window.alert('Usuario modificado Exitosamente');</script>");
        //}

        //protected void Button4_Click(object sender, EventArgs e)
        //{
        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("delete from USUARIO where correo='" + TextBox13.Text + "' and contraseña='" + TextBox14.Text + "' ", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader();

        //    dr.Close();
        //    coneccion.Close();

        //    Label16.Text = "se elimino el registro";
        //    this.Page.Response.Write("<script language='JavaScript'>window.alert('Usuario eliminado Exitosamente');</script>");

        //}

        ////cerrar cession
        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    Session.Remove("usuario");
        //    Response.Redirect("Ingresar.aspx");
        //}

        ////crear proyecto
        //protected void Button6_Click(object sender, EventArgs e)
        //{

        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("Insert into PROYECTO (nombre, fecha_inicio , fecha_fin, presupuesto, duracion ) values('" + TextBox17.Text + "','" + TextBox18.Text + "','" + TextBox19.Text + "','" + TextBox20.Text + "','" + TextBox21.Text + "')", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    dr.Close();
        //    coneccion.Close();
        //    this.Page.Response.Write("<script language='JavaScript'>window.alert('Usuario modificado Exitosamente');</script>");

        //}

        //protected void Button7_Click(object sender, EventArgs e)
        //{

        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("Update PROYECTO set nombre='"+TextBox22.Text+"', fecha_inicio='"+TextBox23.Text+"', fecha_fin='"+TextBox24.Text+"', presupuesto='"+TextBox25.Text+"' , duracion='"+TextBox26.Text+ "' where CONVERT(VARCHAR, nombre)='" + DropDownList3.Text+"' ", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    dr.Close();
        //    coneccion.Close();
        //    this.Page.Response.Write("<script language='JavaScript'>window.alert('Usuario modificado Exitosamente');</script>");

        //}

        //protected void Button8_Click(object sender, EventArgs e)
        //{
        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("delete from PROYECTO where presupuesto='"+TextBox28.Text+"' and duracion='"+TextBox29.Text+"' ", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    dr.Close();
        //    coneccion.Close();
        //    this.Page.Response.Write("<script language='JavaScript'>window.alert('Usuario modificado Exitosamente');</script>");

        //}

        //protected void Button5_Click(object sender, EventArgs e)
        //{
        //    TableCell cc1 = new TableCell();
        //    cc1.Text = "Correo";
        //    TableCell cc2 = new TableCell();
        //    cc2.Text = "Contraseña";
        //    TableCell cc3 = new TableCell();
        //    cc3.Text = "Nombre Completo";
        //    TableCell cc4 = new TableCell();
        //    cc4.Text = "Fecha de nacimiento";
        //    TableCell cc5 = new TableCell();
        //    cc5.Text = "Direccion";
        //    TableCell cc6 = new TableCell();
        //    cc6.Text = "Telefono";

        //    TableRow roww = new TableRow();
        //    roww.Controls.Add(cc1);
        //    roww.Controls.Add(cc2);
        //    roww.Controls.Add(cc3);
        //    roww.Controls.Add(cc4);
        //    roww.Controls.Add(cc5);
        //    roww.Controls.Add(cc6);
        //    Table1.Controls.Add(roww);
        //    coneccion.ConnectionString = "Data Source=DESKTOP-3NVLS4G\\SQLEXPRESS;Initial Catalog=Proyectoipc2; Integrated Security =True";
        //    coneccion.Open();
        //    SqlCommand cmd = new SqlCommand("select * from USUARIO where correo='"+TextBox15.Text+"'", coneccion);
        //    SqlDataReader dr = cmd.ExecuteReader(System.Data.CommandBehavior.SingleResult);
        //    while (dr.Read())
        //    {
        //        TableCell c1 = new TableCell();
        //        c1.Text =dr["correo"].ToString();
        //        TableCell c2 = new TableCell();
        //        c2.Text = dr["contraseña"].ToString();
        //        TableCell c3 = new TableCell();
        //        c3.Text = dr["nombre"].ToString();
        //        TableCell c4 = new TableCell();
        //        c4.Text = dr["fecha_nacimiento"].ToString();
        //        TableCell c5 = new TableCell();
        //        c5.Text = dr["direccion"].ToString();
        //        TableCell c6 = new TableCell();
        //        c6.Text = dr["telefono"].ToString();

        //        TableRow row = new TableRow();
        //        row.Controls.Add(c1);
        //        row.Controls.Add(c2);
        //        row.Controls.Add(c3);
        //        row.Controls.Add(c4);
        //        row.Controls.Add(c5);
        //        row.Controls.Add(c6);
        //        Table1.Controls.Add(row);
        //    }
        //    coneccion.Close();
        //    dr.Close();
        //}


        protected void Button1_Click2(object sender, EventArgs e)
        {
            Session.Remove("usuario");
            Response.Redirect("Ingresar.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            ws.Crearagencia(TextBox1.Text,TextBox2.Text,TextBox3.Text);
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            ws.añadirgerente(Convert.ToInt32( TextBox4.Text),TextBox5.Text);
        }

        protected void Button44_Click(object sender, EventArgs e)
        {
            ws.Añadirempleado(TextBox6.Text,TextBox7.Text,TextBox8.Text,DropDownList61.Text,Convert.ToInt32(TextBox9.Text),Convert.ToInt32(TextBox10));
        }
    }
}