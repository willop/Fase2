﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace ProyectoIPC2
{
    public partial class Desarrollo : System.Web.UI.Page
    {
        //variables
        ServiceReference1.Webservicefase2Client ws = new ServiceReference1.Webservicefase2Client();


        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string nombreusuario = Session["usuario"].ToString();
                Label1.Text = nombreusuario;
            }
            catch (Exception ex)
            {
                Response.Redirect("Ingresar.aspx");
            }
        }




        //----------------------crear usuario

        //modificar usuario por medio del correo
        

        //protected void Button4_Click(object sender, EventArgs e)
        //{
        //    Label16.Text = "hola dio click";
        //}

        //cerrar cession
        protected void Button9_Click(object sender, EventArgs e)
        {
            Session.Remove("usuario");
            Response.Redirect("Ingresar.aspx");
        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            ws.Aperturacuentaindividual(Convert.ToInt32(TextBox4.Text),DropDownList14.Text,Convert.ToInt32(TextBox6.Text),TextBox2.Text, Convert.ToDouble(TextBox7.Text));
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            ws.Solicituddeprestamo(Convert.ToInt32( TextBox1.Text),1, "En espera", Convert.ToDouble(TextBox3.Text),DropDownList2.Text);
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            ws.Aperturacuentaempresarial(TextBox5.Text,TextBox5.Text+"ususario",TextBox5.Text+"password",TextBox8.Text,TextBox9.Text,TextBox10.Text,TextBox11.Text);
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            ws.Estadocuenta(Convert.ToInt32( TextBox15.Text),TextBox16.Text,DropDownList3.Text );
        }
    }
}