﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;


namespace ProyectoIPC2
{
    public partial class Ingresar : System.Web.UI.Page
    {
        //variables globales
        string rol;
        string nombre;
       
        ServiceReference1.Webservicefase2Client ws = new ServiceReference1.Webservicefase2Client();


        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            Boolean respuesta = false;


            
            nombre = TextBox1.Text;

            respuesta = ws.Login(nombre, TextBox2.Text);


            if (DropDownList1.Text=="Cliente")
            {
                rol = "1";
            }
            if (DropDownList1.Text == "Empresa")
            {
                rol = "2";
            }
            if (DropDownList1.Text == "Cajero")
            {
                rol = "3";
            }
            else if (DropDownList1.Text == "Gerente General")
            {
                rol = "4";
            }


            this.Page.Response.Write("<script language='JavaScript'>window.alert(' Bienvenido usuario ');</script>");

            if (respuesta==true)
            {
                this.Page.Response.Write("<script language='JavaScript'>window.alert(' usuario y contraseña correcto ');</script>");
                if (rol.Equals("1"))
                {
                    Session["usuario"] = nombre;
                    this.Response.Redirect("Serviciocliente.aspx");
                }
                if (rol.Equals("2"))
                {
                    Session["usuario"] = nombre;
                    this.Response.Redirect("Empresa.aspx");
                }
                if (rol.Equals("3"))
                {
                    Session["usuario"] = nombre;
                    this.Response.Redirect("Cajero.aspx");
                }
                else if (rol.Equals("4"))
                {
                    Session["usuario"] = nombre;
                    this.Response.Redirect("Gerencial.aspx");
                }
                

            }

            
            else
            {
                this.Page.Response.Write("<script language='JavaScript'>window.alert(' Usuario o contraseña incorrecta,     Intente de nuevo ');</script>");
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox1.Focus();
            }

            //string mensajes = "presiono el boton registrarse" + correo;// +"\nContraseña: "+TextBox2.Text+"\nTipo: "+DropDownList1.Text;
            //this.Page.Response.Write("<script language='JavaScript'>window.alert('" + mensajes + "');</script>");

        }
    }


}