﻿$(document).ready(function () {
    var altura = $('.menu').offset().top;
     $(window).on('scroll', function () {
        if ($(window).scrollTop() > altura) {
            $('.menu').addClass('menu-fixed');
            $('.menu-despliegue').addClass('boton-despliegue-fixed');
            $('.left-panel').addClass('left-panel-fixed');

        }
        else {
            $('.menu').removeClass('menu-fixed');
            $('.menu-despliegue').removeClass('boton-despliegue-fixed');
            $('.left-panel').removeClass('left-panel-fixed');
        }
    });
});